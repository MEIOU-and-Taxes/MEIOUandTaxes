from matplotlib import pyplot as plt
import pandas as pd

def get_data(t, i):
    lst = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            lst.append(float(t[loc:end].strip().split(':')[1].strip()))
            loc = end
        else:
            break

    return lst

import os
def read_and_concatenate_old_logs(directory='.'):
    concatenated_text = ''
    for file_name in sorted(os.listdir(directory)):
        if file_name.startswith('game_') and file_name.endswith('.log') and file_name != 'game.log':
            with open(file_name, 'r') as f:
                concatenated_text += f.read()
    return concatenated_text

if __name__ == '__main__':
    with open('game.log') as f:
        t = read_and_concatenate_old_logs()
        t += f.read()
        
        CommerceOutput1 = get_data(t, 'Genoa commercial output')
        CommerceOutput2 = get_data(t, 'Venice commercial output')
        CommerceOutput3 = get_data(t, 'Paris commercial output')
        CommerceOutput4 = get_data(t, 'London commercial output')
        CommerceOutput5 = get_data(t, 'Konstantinople commercial output')
        CommerceOutput6 = get_data(t, 'Al Qahira commercial output')
        itr = range(1, len(CommerceOutput1) + 1)

        plt.plot(itr, CommerceOutput1, label="Genoa")
        plt.plot(itr, CommerceOutput2, label="Venice")
        plt.plot(itr, CommerceOutput3, label="Paris")
        plt.plot(itr, CommerceOutput4, label="London")
        plt.plot(itr, CommerceOutput5, label="Konstantinople")
        plt.plot(itr, CommerceOutput6, label="Al Qahira")

        plt.legend(loc=2, ncol=2)

        plt.show()
