from matplotlib import pyplot as plt
from matplotlib.widgets import CheckButtons
from matplotlib.widgets import TextBox
from matplotlib.lines import Line2D
import pandas as pd

def get_data_filtered(t, i, search):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            year.append(int(t[loc:end].strip().split(':')[1].strip()))
            key.append(t[loc:end].strip().split(':')[2].strip())
            country.append(t[loc:end].strip().split(':')[3].strip())
            value.append(float(t[loc:end].strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    filtered_result = result.loc[result['stat'].str.contains(search, case=True, na=False)]
    return filtered_result

def get_data(t, i):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            year.append(int(t[loc:end].strip().split(':')[1].strip()))
            key.append(t[loc:end].strip().split(':')[2].strip())
            country.append(t[loc:end].strip().split(':')[3].strip())
            value.append(float(t[loc:end].strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    return result

import os
def read_and_concatenate_old_logs(directory='.'):
    concatenated_text = ''
    for file_name in sorted(os.listdir(directory)):
        if file_name.startswith('game_') and file_name.endswith('.log') and file_name != 'game.log':
            with open(file_name, 'r') as f:
                concatenated_text += f.read()
    return concatenated_text

if __name__ == '__main__':
    with open('game.log') as f:
        t = read_and_concatenate_old_logs()
        t += f.read()
        
        NOPow = get_data_filtered(t, 'Country Stats', 'NOPow')
        BGPow = get_data_filtered(t, 'Country Stats', 'BGPow')
        CLPow = get_data_filtered(t, 'Country Stats', 'CLPow')
        TRPow = get_data_filtered(t, 'Country Stats', 'TRPow')
        BUPow = get_data_filtered(t, 'Country Stats', 'BUPow')
        itr = NOPow['year'].unique()


        plt.plot(itr, NOPow.groupby('year')['value'].mean(), label="Noble Power")
        plt.plot(itr, BGPow.groupby('year')['value'].mean(), label="Burgher Power")
        plt.plot(itr, CLPow.groupby('year')['value'].mean(), label="Clergy Power")
        plt.plot(itr, TRPow.groupby('year')['value'].mean(), label="Tribal Power")
        plt.plot(itr, BUPow.groupby('year')['value'].mean(), label="State Reach")

        plt.title("Global Average Elite Power")
        plt.legend(loc=2, ncol=2)
        plt.show()