from matplotlib import pyplot as plt
from matplotlib.widgets import CheckButtons
from matplotlib.widgets import TextBox
from matplotlib.lines import Line2D
import pandas as pd

def get_data_filtered(t, i, search):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            text = t[loc:end]
            if text.strip().split(':')[0] == i:
                year.append(int(text.strip().split(':')[1].strip()))
                key.append(text.strip().split(':')[2].strip())
                country.append(text.strip().split(':')[3].strip())
                value.append(float(text.strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    filtered_result = result.loc[result['stat'].str.contains(search, case=True, na=False)]
    return filtered_result

def get_data(t, i):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            text = t[loc:end].strip().split(':')
            if text[0] == i:
                year.append(int(text[1].strip()))
                key.append(text[2].strip())
                country.append(text[3].strip())
                value.append(float(text[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    return result

import os
def read_and_concatenate_old_logs(directory='.'):
    concatenated_text = ''
    for file_name in sorted(os.listdir(directory)):
        if file_name.startswith('game_') and file_name.endswith('.log') and file_name != 'game.log':
            with open(file_name, 'r') as f:
                concatenated_text += f.read()
    return concatenated_text

if __name__ == '__main__':
    with open('game.log') as f:
        t = read_and_concatenate_old_logs()
        t += f.read()
        

        important_tags = ['England', 'France', 'Bohemia', 'Hungary', 'Austria', 'Muscovy', 'Russia', 'Castile', 'Spain', 'Portugal', 'Poland', 'Brandenburg', 'Sweden', 'Venice', 'Florence','Milan']
        df = get_data_filtered(t, 'Rights', 'BU')
        df = df[df['country'].isin(important_tags)]
        itr = df['year'].unique()

        df.loc[df['stat'] == 'BUTax', 'value'] += 1
        df.loc[df['stat'] == 'BUDir', 'value'] += 1
        df.loc[df['stat'] == 'BUInd', 'value'] += 1
        df.loc[df['stat'] == 'BUSer', 'value'] += 1

        fig1, ax1 = plt.subplots()
        lines = {}

        for stat in df['stat'].unique():
            for country in df['country'].unique():
                subset_df = df[(df['stat'] == stat) & (df['country'] == country)]
                if not subset_df.empty:
                    line, = ax1.plot(subset_df['year'], subset_df['value'], label=f'{stat} ({country})', visible=False)
                    lines[f'{stat} ({country})'] = line

        # Create a separate figure for the TextBox
        fig2 = plt.figure()
        text_box_axes = fig2.add_axes([0.1, 0.1, 0.8, 0.8])
        text_box = TextBox(text_box_axes, 'Search')
        
        def search(label):
            query = text_box.text
            visible_lines = []
            for line_label, line in lines.items():
                line.set_visible(False)  # Reset visibility
                if query.lower() in line_label.split(' ')[-1].lower():  # Only check the country part
                    line.set_visible(True)
                    visible_lines.append(line)
            ax1.legend(handles=visible_lines, title='Stats', loc='upper right', ncol=2)
            fig1.canvas.draw_idle()  # Update the main figure


        text_box.on_submit(search)


        # Initialize an empty list for the legend elements and a set for unique categories
        legend_elements = []
        added_stats = set()


        ax1.set_ylim([1, 10])
        ax1.set_title("State Rights - Country Viewer")
        plt.show()
