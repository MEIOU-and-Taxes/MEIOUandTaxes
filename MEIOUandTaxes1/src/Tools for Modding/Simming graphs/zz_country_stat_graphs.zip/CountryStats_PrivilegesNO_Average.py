from matplotlib import pyplot as plt
from matplotlib.widgets import CheckButtons
from matplotlib.widgets import TextBox
from matplotlib.lines import Line2D
import pandas as pd

def get_data_filtered(t, i, search):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            text = t[loc:end].strip().split(':')
            if text[0] == i:
                year.append(int(text[1].strip()))
                key.append(text[2].strip())
                country.append(text[3].strip())
                value.append(float(text[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    filtered_result = result.loc[result['stat'].str.contains(search, case=True, na=False)]
    return filtered_result

def get_data(t, i):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            year.append(int(t[loc:end].strip().split(':')[1].strip()))
            key.append(t[loc:end].strip().split(':')[2].strip())
            country.append(t[loc:end].strip().split(':')[3].strip())
            value.append(float(t[loc:end].strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    return result

import os
def read_and_concatenate_old_logs(directory='.'):
    concatenated_text = ''
    for file_name in sorted(os.listdir(directory)):
        if file_name.startswith('game_') and file_name.endswith('.log') and file_name != 'game.log':
            with open(file_name, 'r') as f:
                concatenated_text += f.read()
    return concatenated_text

if __name__ == '__main__':
    with open('C:/Users/Nico/Documents/Paradox Interactive/Europa Universalis IV/logs/game.log') as f:
        t = read_and_concatenate_old_logs()
        t += f.read()
        
        df = get_data_filtered(t, 'Privilege', 'NO')
        NOProcessing  = df.loc[df['stat'] =='NOProcessing']
        NOGame        = df.loc[df['stat'] =='NOGame']
        NOForestry    = df.loc[df['stat'] =='NOForestry']
        NOSeigneurial = df.loc[df['stat'] =='NOSeigneurial']
        NOAutonomy    = df.loc[df['stat'] =='NOAutonomy']
        NODiplomacy   = df.loc[df['stat'] =='NODiplomacy']
        NODynastic    = df.loc[df['stat'] =='NODynastic']
        NOHierarchy   = df.loc[df['stat'] =='NOHierarchy']
        NOTaxE        = df.loc[df['stat'] =='NOTaxE']
        NOServiceE    = df.loc[df['stat'] =='NOServiceE']

        NOProcessing['value'] = NOProcessing['value']+1
        NOGame['value'] = NOGame['value']+1
        NOForestry['value'] = NOForestry['value']+1
        NOSeigneurial['value'] = NOSeigneurial['value']+1
        NOAutonomy['value'] = NOAutonomy['value']+1
        NODiplomacy['value'] = NODiplomacy['value']+1
        NODynastic['value'] = NODynastic['value']+1
        NOHierarchy['value'] = NOHierarchy['value']+1
        NOTaxE['value'] = NOTaxE['value']+1
        NOServiceE['value'] = NOServiceE['value']+1
        
        itr = NOProcessing['year'].unique()

        plt.plot(itr, NOProcessing.groupby('year')['value'].mean(),     label="Processing Monopoly")
        plt.plot(itr, NOGame.groupby('year')['value'].mean(),           label="Game Monopoly")
        plt.plot(itr, NOForestry.groupby('year')['value'].mean(),       label="Forestry Monopoly")
        plt.plot(itr, NOSeigneurial.groupby('year')['value'].mean(),    label="Seigneurial Courts")
        plt.plot(itr, NOAutonomy.groupby('year')['value'].mean(),       label="Rural Autonomy")
        plt.plot(itr, NODiplomacy.groupby('year')['value'].mean(),      label="Prestigious Diplomacy")
        plt.plot(itr, NODynastic.groupby('year')['value'].mean(),       label="Familial Service")
        plt.plot(itr, NOHierarchy.groupby('year')['value'].mean(),      label="Noble Hierarchy")
        plt.plot(itr, NOTaxE.groupby('year')['value'].mean(),           label="Noble Dues")
        plt.plot(itr, NOServiceE.groupby('year')['value'].mean(),       label="Noble Service")

        plt.title("Global Average Noble Privilege Level")
        plt.ylim(bottom=1)
        plt.legend(loc=2, ncol=2)
        plt.show()
