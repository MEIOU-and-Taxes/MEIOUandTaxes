from matplotlib import pyplot as plt
from matplotlib.widgets import CheckButtons
from matplotlib.widgets import TextBox
from matplotlib.lines import Line2D
import pandas as pd

def get_data_filtered(t, i, search):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            year.append(int(t[loc:end].strip().split(':')[1].strip()))
            key.append(t[loc:end].strip().split(':')[2].strip())
            country.append(t[loc:end].strip().split(':')[3].strip())
            value.append(float(t[loc:end].strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    filtered_result = result.loc[result['stat'].str.contains(search, case=True, na=False)]
    return filtered_result

def get_data(t, i):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            year.append(int(t[loc:end].strip().split(':')[1].strip()))
            key.append(t[loc:end].strip().split(':')[2].strip())
            country.append(t[loc:end].strip().split(':')[3].strip())
            value.append(float(t[loc:end].strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    return result

import os
def read_and_concatenate_old_logs(directory='.'):
    concatenated_text = ''
    for file_name in sorted(os.listdir(directory)):
        if file_name.startswith('game_') and file_name.endswith('.log') and file_name != 'game.log':
            with open(file_name, 'r') as f:
                concatenated_text += f.read()
    return concatenated_text

if __name__ == '__main__':
    with open('game.log') as f:
        t = read_and_concatenate_old_logs()
        t += f.read()
        

        NOLoy = get_data_filtered(t, 'Country Stats', 'NOLoy')
        BGLoy = get_data_filtered(t, 'Country Stats', 'BGLoy')
        CLLoy = get_data_filtered(t, 'Country Stats', 'CLLoy')
        TRLoy = get_data_filtered(t, 'Country Stats', 'TRLoy')
        BULoy = get_data_filtered(t, 'Country Stats', 'BULoy')
        itr = NOLoy['year'].unique()


        plt.plot(itr, NOLoy.groupby('year')['value'].mean(), label="Noble Loyalty")
        plt.plot(itr, BGLoy.groupby('year')['value'].mean(), label="Burgher Loyalty")
        plt.plot(itr, CLLoy.groupby('year')['value'].mean(), label="Clergy Loyalty")
        plt.plot(itr, TRLoy.groupby('year')['value'].mean(), label="Tribal Loyalty")
        plt.plot(itr, BULoy.groupby('year')['value'].mean(), label="Provincial Corruption")

        plt.title("Global Average Elite Loyalty")
        plt.legend(loc=2, ncol=2)
        plt.show()
