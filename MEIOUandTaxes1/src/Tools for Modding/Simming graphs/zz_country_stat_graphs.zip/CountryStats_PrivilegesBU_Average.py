from matplotlib import pyplot as plt
from matplotlib.widgets import CheckButtons
from matplotlib.widgets import TextBox
from matplotlib.lines import Line2D
import pandas as pd

def get_data_filtered(t, i, search):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            text = t[loc:end].strip().split(':')
            if text[0] == i:
                year.append(int(text[1].strip()))
                key.append(text[2].strip())
                country.append(text[3].strip())
                value.append(float(text[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    filtered_result = result.loc[result['stat'].str.contains(search, case=True, na=False)]
    return filtered_result

def get_data(t, i):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            year.append(int(t[loc:end].strip().split(':')[1].strip()))
            key.append(t[loc:end].strip().split(':')[2].strip())
            country.append(t[loc:end].strip().split(':')[3].strip())
            value.append(float(t[loc:end].strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    return result

import os
def read_and_concatenate_old_logs(directory='.'):
    concatenated_text = ''
    for file_name in sorted(os.listdir(directory)):
        if file_name.startswith('game_') and file_name.endswith('.log') and file_name != 'game.log':
            with open(file_name, 'r') as f:
                concatenated_text += f.read()
    return concatenated_text

if __name__ == '__main__':
    with open('C:/Users/Nico/Documents/Paradox Interactive/Europa Universalis IV/logs/game.log') as f:
        t = read_and_concatenate_old_logs()
        t += f.read()
        
        df = get_data_filtered(t, 'Privilege', 'BU')
        BUOffice    = df.loc[df['stat'] =='BUOffice']
        BUFarm      = df.loc[df['stat'] =='BUFarm']
        BUTenure    = df.loc[df['stat'] =='BUTenure']
        BUWages     = df.loc[df['stat'] =='BUWages']
        BUHierarchy = df.loc[df['stat'] =='BUHierarchy']
        BUHire      = df.loc[df['stat'] =='BUHire']
        BUExams     = df.loc[df['stat'] =='BUExams']
        BUOversight = df.loc[df['stat'] =='BUOversight']
        BUEnlist    = df.loc[df['stat'] =='BUEnlist']
        BUStructure = df.loc[df['stat'] =='BUStructure']
        BUCourts    = df.loc[df['stat'] =='BUCourts']
        BUPolitics  = df.loc[df['stat'] =='BUPolitics']
        BURotate    = df.loc[df['stat'] =='BURotate']

        BUOffice['value']   = BUOffice['value']+1
        BUFarm['value']     = BUFarm['value']+1
        BUTenure['value']   = BUTenure['value']+1
        BUWages['value']    = BUWages['value']+1
        BUHierarchy['value']= BUHierarchy['value']+1
        BUHire['value']     = BUHire['value']+1
        BUExams['value']    = BUExams['value']+1
        BUOversight['value']= BUOversight['value']+1
        BUEnlist['value']   = BUEnlist['value']+1
        BUStructure['value']= BUStructure['value']+1
        BUCourts['value']   = BUCourts['value']+1
        BUPolitics['value'] = BUPolitics['value']+1
        BURotate['value']   = BURotate['value']+1
        
        itr = BUOffice['year'].unique()

        plt.plot(itr, BUOffice.groupby('year')['value'].mean(),   label="Sale of Office")
        plt.plot(itr, BUFarm.groupby('year')['value'].mean(),     label="Tax Farming")
        plt.plot(itr, BUTenure.groupby('year')['value'].mean(),   label="Term of Office")
        plt.plot(itr, BUWages.groupby('year')['value'].mean(),    label="Official Wages")
        plt.plot(itr, BUHierarchy.groupby('year')['value'].mean(),label="Bureaucratic Hierarchy")
        plt.plot(itr, BUHire.groupby('year')['value'].mean(),     label="Means of Recruitment")
        plt.plot(itr, BUExams.groupby('year')['value'].mean(),    label="Civil Examinations")
        plt.plot(itr, BUOversight.groupby('year')['value'].mean(),label="Insititutional Oversight")
        plt.plot(itr, BUEnlist.groupby('year')['value'].mean(),   label="Entry Requirements")
        plt.plot(itr, BUStructure.groupby('year')['value'].mean(),label="Provincial Administration")
        plt.plot(itr, BUCourts.groupby('year')['value'].mean(),   label="Sovereign Courts")
        plt.plot(itr, BUPolitics.groupby('year')['value'].mean(), label="Bureaucratic Politicisation")
        plt.plot(itr, BURotate.groupby('year')['value'].mean(),   label="Regional Tenure")

        plt.title("Global Average Bureaucratic Privilege Level")
        plt.ylim(bottom=1)
        plt.legend(loc=2, ncol=2)
        plt.show()
