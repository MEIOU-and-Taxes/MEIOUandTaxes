from matplotlib import pyplot as plt
from matplotlib.widgets import CheckButtons
from matplotlib.widgets import TextBox
from matplotlib.lines import Line2D
import pandas as pd

def get_data_filtered(t, i, search):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            text = t[loc:end].strip().split(':')
            if text[0] == i:
                year.append(int(text[1].strip()))
                key.append(text[2].strip())
                country.append(text[3].strip())
                value.append(float(text[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    filtered_result = result.loc[result['stat'].str.contains(search, case=True, na=False)]
    return filtered_result

def get_data(t, i):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            year.append(int(t[loc:end].strip().split(':')[1].strip()))
            key.append(t[loc:end].strip().split(':')[2].strip())
            country.append(t[loc:end].strip().split(':')[3].strip())
            value.append(float(t[loc:end].strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    return result

import os
def read_and_concatenate_old_logs(directory='.'):
    concatenated_text = ''
    for file_name in sorted(os.listdir(directory)):
        if file_name.startswith('game_') and file_name.endswith('.log') and file_name != 'game.log':
            with open(file_name, 'r') as f:
                concatenated_text += f.read()
    return concatenated_text

if __name__ == '__main__':
    with open('game.log') as f:
        t = read_and_concatenate_old_logs()
        t += f.read()
        

        BUTax = get_data_filtered(t, 'Rights', 'BUTax')
        BUDir = get_data_filtered(t, 'Rights', 'BUDir')
        BUInd = get_data_filtered(t, 'Rights', 'BUInd')
        BUSer = get_data_filtered(t, 'Rights', 'BUSer')
        BUTax['value'] = BUTax['value']+1
        BUDir['value'] = BUDir['value']+1
        BUInd['value'] = BUInd['value']+1
        BUSer['value'] = BUSer['value']+1
        itr = BUTax['year'].unique()


        plt.plot(itr, BUTax.groupby('year')['value'].mean(), label="Tax Collection Law")
        plt.plot(itr, BUDir.groupby('year')['value'].mean(), label="Direct Taxation Law")
        plt.plot(itr, BUInd.groupby('year')['value'].mean(), label="Indirect Taxation Law")
        plt.plot(itr, BUSer.groupby('year')['value'].mean(), label="Military Service Law")

        plt.title("Global Average Bureaucratic Reform Level")
        plt.legend(loc=2, ncol=2)
        plt.show()
