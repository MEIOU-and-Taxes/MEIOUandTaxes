from matplotlib import pyplot as plt
from matplotlib.widgets import CheckButtons
from matplotlib.widgets import TextBox
from matplotlib.lines import Line2D
import pandas as pd

def get_data_filtered(t, i, search):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            text = t[loc:end].strip().split(':')
            if text[0] == i:
                year.append(int(text[1].strip()))
                key.append(text[2].strip())
                country.append(text[3].strip())
                value.append(float(text[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    filtered_result = result.loc[result['stat'].str.contains(search, case=True, na=False)]
    return filtered_result

def get_data(t, i):
    year=[]
    key=[]
    country = []
    value = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            year.append(int(t[loc:end].strip().split(':')[1].strip()))
            key.append(t[loc:end].strip().split(':')[2].strip())
            country.append(t[loc:end].strip().split(':')[3].strip())
            value.append(float(t[loc:end].strip().split(':')[4].strip()))
            loc = end
        else:
            break
    result = pd.DataFrame({'stat':key, 'country': country, 'value': value, 'year':year})
    return result

import os
def read_and_concatenate_old_logs(directory='.'):
    concatenated_text = ''
    for file_name in sorted(os.listdir(directory)):
        if file_name.startswith('game_') and file_name.endswith('.log') and file_name != 'game.log':
            with open(file_name, 'r') as f:
                concatenated_text += f.read()
    return concatenated_text

if __name__ == '__main__':
    with open('game.log') as f:
        t = read_and_concatenate_old_logs()
        t += f.read()
        

        NOGov = get_data_filtered(t, 'Rights', 'NOGov')
        NOObl = get_data_filtered(t, 'Rights', 'NOObl')
        NOTen = get_data_filtered(t, 'Rights', 'NOTen')
        NOSer = get_data_filtered(t, 'Rights', 'NOSer')
        NOGov['value'] = NOGov['value']+4
        NOObl['value'] = NOObl['value']+3
        NOTen['value'] = NOTen['value']+4
        NOSer['value'] = NOSer['value']+2
        itr = NOGov['year'].unique()


        plt.plot(itr, NOGov.groupby('year')['value'].mean(), label="Rural Governance")
        plt.plot(itr, NOObl.groupby('year')['value'].mean(), label="Noble Obligations")
        plt.plot(itr, NOTen.groupby('year')['value'].mean(), label="Tenacy Law")
        plt.plot(itr, NOSer.groupby('year')['value'].mean(), label="Military Organisation Law")

        plt.title("Global Average Nobility Reform Level")
        plt.legend(loc=2, ncol=2)
        plt.show()
