from matplotlib import pyplot as plt
import pandas as pd

def get_data(t, i):
    lst = []
    loc = 0

    while True:
        loc = t.find(i, loc)

        if loc != -1:
            end = t.find('\n', loc)
            lst.append(float(t[loc:end].strip().split(':')[1].strip()))
            loc = end
        else:
            break

    return lst

if __name__ == '__main__':
    with open('game.log') as f:
        t = f.read()
        
        wealth = get_data(t, 'Bureau Income Property')
        wealth2 = get_data(t, 'Bureau Property Injection')
        wealth3 = get_data(t, 'Bureau Spend Property')
        wealth4 = get_data(t, 'Bureau Spend Manpower')
        wealth5 = get_data(t, 'Bureau Property Injection')
        wealth6 = get_data(t, 'Bureau Income')
        itr = range(1, len(wealth) + 1)

        #plt.plot(itr, wage, label="Total")
        plt.plot(itr, wealth, label="Bureau Income Property")
        plt.plot(itr, wealth2, label="Bureau Property Injection")
        plt.plot(itr, wealth3, label="Bureau Spend Property")
        plt.plot(itr, wealth4, label="Bureau Spend Manpower")
        plt.plot(itr, wealth5, label="Bureau Property Injection")
        plt.plot(itr, wealth6, label="Bureau Income")

        plt.legend(loc=2, ncol=2)

        plt.show()
